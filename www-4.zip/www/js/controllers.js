angular.module('starter.controllers', ['jett.ionic.filter.bar', 'aCarousel',/*'ionic-material'*/ ])

.controller('AppCtrl', function($rootScope, $scope, $ionicModal, $timeout,$state) {
    initImagesSettings();
    function initImagesSettings(argument) {
        $rootScope.images = [];
        $rootScope.searchCriteria = {
            page : 1,
            orientation : 'all',
            editors_choice : false,
            order : 'popular',
            per_page : 12,
            image_type: 'all'
        };
        $scope.showSearchCriteriaOrientation = true;
        $rootScope.catrgories = ['all','fashion', 'nature', 'backgrounds', 'science', 'education', 'people', 'feelings', 'religion', 'health', 'places', 'animals', 'industry', 'food', 'computer', 'sports', 'transportation', 'travel', 'buildings', 'business', 'music'];

    }


    $scope.loginData = {};
    $ionicModal.fromTemplateUrl('templates/login.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    // Open the login modal
    $scope.login = function() {
        $scope.modal.show();
    };
    // Perform the login action when the user submits the login form
    $scope.doLogin = function() {
        console.log('Doing login', $scope.loginData);
        // Simulate a login delay. Remove this and replace with your login
        // code if using a login system
        $timeout(function() {
            $scope.closeLogin();
        }, 1000);
    };
    function doOnOrientationChange()
    {
        switch(window.orientation) 
        {  
            case -90:
            case 90:
                // alert('landscape');
                $rootScope.orientation = 'landscape';
                break; 
            default:
                $rootScope.orientation = 'portrait';
                // alert('portrait');
            break; 
        }
    }

    window.addEventListener('orientationchange', doOnOrientationChange);
    $scope.navBarTransparent = true;
    $scope.displaySearchButton = true;
})

.controller('brickCtrl',ImageListCtrlBCk)

.controller('CategoryCtrl',CategoryCtrl)

.controller('searchCtrl', function($scope, $ionicSlideBoxDelegate, $rootScope){
    
    // $rootScope.tabCondition = {"key": 'order', "val" : "popular"};
    $scope.slideHasChanged = function() {
        return;
        var slide_index  = $ionicSlideBoxDelegate.currentIndex();

        switch(slide_index){
            case 0:
                $rootScope.tabCondition.key = 'order';
                $rootScope.tabCondition.val = 'popular';
                break;
            
            case 1:
                $rootScope.tabCondition.key = 'order';
                $rootScope.tabCondition.val = 'latest';
                break;
            
            case 2:
                $rootScope.tabCondition.key = 'image_type';
                $rootScope.tabCondition.val = 'photo';
                break;
            
            case 3:
                $rootScope.tabCondition.key = 'image_type';
                $rootScope.tabCondition.val = 'illustration';
                break;
            
            case 4:
                $rootScope.tabCondition.key = 'image_type';
                $rootScope.tabCondition.val = 'vector';
                break;
        }
    };
})

/*
.controller('searchCtrl', function($log,$ionicSlideBoxDelegate,$scope,$rootScope, $timeout, imageService, $ionicFilterBar, $ionicLoading) { 

    var vm = this,
        instance, 
        rowGridInit = false, 
        self = this,
        changeSearchCriteriaOrientation = true,
        isLoadMoreStart = false,
        sizes = [
            { columns: 3, gutter: 5 },
            { mq: '400px', columns: 3, gutter: 5 },
            { mq: '500px', columns: 4, gutter: 5 }
        ],
        previousCategotyId = 0;

    $rootScope.catrgories = ['all','fashion', 'nature', 'backgrounds', 'science', 'education', 'people', 'feelings', 'religion', 'health', 'places', 'animals', 'industry', 'food', 'computer', 'sports', 'transportation', 'travel', 'buildings', 'business', 'music'];

    $scope.hasMoreImages = true;
    $scope.showSubHeader = true;

    $scope.loadMore = loadMore;
    $scope.doRefresh = doRefresh;

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.beforeEnter', function() {});
    $scope.$on('$ionicView.afterEnter', function() {
        // loadMore();
        $rootScope.showSearchCriteriaOrientation = true;
        $timeout(function(){
        $scope.$broadcast('acarousel.setitemactive', {id:3,display:'Backgrounds'});
        $scope.$emit('acarousel.setitemactive', {id:3,display:'Backgrounds'});
        $scope.$broadcast('a-carousel.arrayupdated', 'carousel');
    },1000 );
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });
    // $rootScope.tabPageList = {popular:0,latest:0,photo:0,illustration:0,vector:0};
    $rootScope.pageList = [0,0,0,0,0];
    $rootScope.tabPageList = [0,0,0,0,0];
    $scope.slide_index = 0;
    $scope.slideHasChanged = function() {
        $scope.slide_index  = $ionicSlideBoxDelegate.currentIndex();
        $rootScope.searchCriteria.image_type = 'all';
        $rootScope.searchCriteria.order = 'popular';
        $rootScope.searchCriteria.per_page = tabPageList[slide_index];

        switch(slide_index){
            case 0:
                $rootScope.searchCriteria.order = 'popular';
                break;
            
            case 1:
                $rootScope.searchCriteria.order = 'latest';
                break;
            
            case 2:
                $rootScope.searchCriteria.image_type = 'photo';
                break;
            
            case 3:
                $rootScope.searchCriteria.image_type = 'illustration';
                break;
            
            case 4:
                $rootScope.searchCriteria.image_type = 'vector';
                break;
        }
    };

    init();

    function init() {
        // Set Ink
    }
    function loadMore(cb) {
        if (isLoadMoreStart) {
            return;
        }
        isLoadMoreStart = true;
        imageService
            .getImages($rootScope.searchCriteria)
            .then(function (result) {
                $rootScope.searchCriteria.page += 1;
                $rootScope.images = $rootScope.images.concat(result);
            }, function (error) {
                $scope.hasMoreImages = false;
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(items) {
                    calculateOnImageLoad(function(){
                        brickLoader();
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        isLoadMoreStart = false;
                        if (typeof cb == 'function') {
                            cb();
                        }
                    });
                },200);
            });
    }
    function doRefresh(tab, cb) {
        rowGridInit = false;
        $rootScope.pageList.page = 1;
        $rootScope.image_list.tab = [];
        $timeout(function(){
            loadMore(cb);
        },0);
    }
    function brickLoader(){
        try{
            if (!rowGridInit) {
                instance = Bricks({
                   container: '#brick-container',
                   sizes: sizes,
                   packed: 'data-packed'
                })
                instance .resize(true);
                instance.pack();
                instance
                .on('pack',   () => console.log('ALL grid items packed.'))
                .on('update', () => console.log('NEW grid items packed.'))
                .on('resize', function (size) {$log.info(size);})
                rowGridInit = true;
                $log.info("#####--------init--------######");
            } else {
                
                    instance.update()
               
                $log.info("#####--------update--------######");
            }
        } catch (e){$log.info("#####--------brick error happen--------######");}
    }
    function calculateOnImageLoad(cb) {
        var currentlyLoaded = 0;

        var items = document.querySelectorAll("#brick-container > *:not([data-packed]) img"), 
            totalImg = items.length, 
            img;
        for (var i = 0; i < totalImg; i++) {
            img = items[i];
            
            (function(i) {
                if (img.complete) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                    return;
                }
                img.addEventListener("load", function(loadimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                });
                img.addEventListener("error", function(errorimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    items[i].parentNode.classList.add('error');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                });
            })(i);
        }
        function setOpacity1(){
            for (var i = 0; i < totalImg; i++) {
                items[i].style.opacity = 1;
                items[i].parentNode.classList.remove('loading');
            }
        }
    }
})
*/


.controller('popularCtrl', ImageListCtrl)

.controller('latestCtrl', ImageListCtrl)

.controller('photoCtrl', ImageListCtrl)

.controller('illustrationCtrl', ImageListCtrl)

.controller('vectorCtrl', ImageListCtrl)

.controller('imageCtrl', function($scope,$rootScope,$state,$stateParams, $ionicSlideBoxDelegate, $ionicGesture) {
    if (!$rootScope.images[parseInt($stateParams.id)]) {
        $state.go('app.brick');
    }
    $scope.image_slides = [];
    for (var i = 0; i < 5; i++) {
        if (!$rootScope.images[parseInt($stateParams.id)]) {
            $state.go('app.brick');
        }
        $scope.image_slides.push({
            'src': $rootScope.images[parseInt($stateParams.id) + i].webformatURL,
        });
    }
    document.getElementsByTagName("ion-header-bar")

    $scope.slideHasChanged = function() {
        $scope.image_slides.splice($scope.image_slides.length - 1)
        $scope.image_slides.push({
            // 'src': 'http://lorempixel.com/360/640?' + ($ionicSlideBoxDelegate.currentIndex() + 3)
            'src': $rootScope.images[parseInt($stateParams.id) + (i++)].webformatURL
        });
        $ionicSlideBoxDelegate.update();
    };
    $scope.$on('$ionicView.enter', function() {
        $scope.$parent.navBarTransparent = true;
        $scope.$parent.displaySearchButton = false;
        $scope.$parent.hideSheetFav = true;
        document.querySelector('ion-nav-view[name="fabContent"]').style.display = 'none';

    });
    $scope.$on('$ionicView.afterLeave', function() {
        $scope.$parent.navBarTransparent = false;
        $scope.$parent.displaySearchButton = true;
        document.querySelector('ion-nav-view[name="fabContent"]').style.display = 'block';

    });
    $scope.$on('$ionicView.afterEnter', function() {
        setTimeout(function() {
            document.querySelector('.slider-container .slider-slides').style.transform = "translate(0px, 0px) translateZ(0px)";
        }, 500);
        document.querySelector('.slider-container .slider-slides').style.transform = "translate(-60px, 0px) translateZ(0px)";
    });
})


// -------

    .controller('DashCtrl', function($scope, $ionicSideMenuDelegate, $ionicTabsDelegate) {

        var deploy = new Ionic.Deploy();
        // Update app code with new release from Ionic Deploy
        $scope.doUpdate = function() {
            deploy.update().then(function(res) {
                console.log('Ionic Deploy: Update Success! ', res);
            }, function(err) {
                console.log('Ionic Deploy: Update error! ', err);
            }, function(prog) {
                console.log('Ionic Deploy: Progress... ', prog);
            });
        };
        // Check Ionic Deploy for new code
        $scope.checkForUpdates = function() {
            console.log('Ionic Deploy: Checking for updates');
            deploy.check().then(function(hasUpdate) {
                console.log('Ionic Deploy: Update available: ' + hasUpdate);
                $scope.hasUpdate = hasUpdate;
            }, function(err) {
                console.error('Ionic Deploy: Unable to check for updates', err);
            });
        }
        $ionicSideMenuDelegate.canDragContent(false);
                    $scope.previousTab = 0;
        $scope.currentTab = 0;
        $scope.$watch(function() {return $ionicTabsDelegate.selectedIndex();}, function(index) {
              $scope.previousTab = $scope.currentTab;
              $scope.currentTab = index;
        });
    })
// ---------
.directive('tabsSwipable', ['$ionicGesture', function($ionicGesture){
    return {
        restrict: 'A',
        require: 'ionTabs',
        link: function(scope, elm, attrs, tabsCtrl){
            var onSwipeLeft = function(){
                var target = tabsCtrl.selectedIndex() + 1;
                if(target < tabsCtrl.tabs.length){
                    scope.$apply(tabsCtrl.select(target));
                }
            };
            var onSwipeRight = function(){
                var target = tabsCtrl.selectedIndex() - 1;
                if(target >= 0){
                    scope.$apply(tabsCtrl.select(target));
                }
            };
            
            var swipeGesture = $ionicGesture.on('swipeleft', onSwipeLeft, elm).on('swiperight', onSwipeRight);
            scope.$on('$destroy', function() {
                $ionicGesture.off(swipeGesture, 'swipeleft', onSwipeLeft);
                $ionicGesture.off(swipeGesture, 'swiperight', onSwipeRight);
            });
        }
    };
}])

.directive('scrollWatch', function($rootScope) {
  return function(scope, elem, attr) {
    var start = 150, is_scrolling = false;
    document.getElementById(attr.subHeader).style.top = '44px';
    elem[0].style.top = '88px';
    elem[0].style.transition = 'top 0.25s ease';
    elem.bind('scroll', function(e) {
        if (is_scrolling || !scope.showSubHeader) {return;}
        is_scrolling = true;

        
        (function(e){
            setTimeout(function(){
                var scrollTop = (e.detail)?e.detail.scrollTop : e.target.scrollTop;
                if(scrollTop > start) {
                    document.getElementById(attr.subHeader).style.top = '0px';
                    elem[0].style.top = '44px';
                } else {
                    document.getElementById(attr.subHeader).style.top = '44px';
                    elem[0].style.top = '88px';
                }
                start = scrollTop;
                is_scrolling = false;
            },500);
        })(e);
    });
  };
})

.directive('scrollWatch2', function($rootScope) {
  return function(scope, elem, attr) {
    var start = 150, is_scrolling = false;
    var header = document.querySelector('.nav-bar-block[nav-bar="active"] ion-header-bar');
    if (!header) {
        header = document.querySelector('.nav-bar-block[nav-bar="entering"] ion-header-bar');
    }
    // var navcontainer = document.querySelector('ion-nav-view[name="menuContent"]');
    // document.querySelector('nav-bar-block[nav-bar="active"]').style.zIndex = '10';
    var container = document.querySelector('#tab-scroll-container');
    // container.style.transition = 'top 0.25s ease';
    // header.style.transition = 'top 0.25s ease, opacity 0.75s ease';
    // navcontainer.style.zIndex = '9';
    elem.bind('scroll', function(e) {
        if (is_scrolling 
            // || !scope.showSubHeader
            ) {return;}
        is_scrolling = true;

        
        (function(e){
            setTimeout(function(){
                var scrollTop = (e.detail)?e.detail.scrollTop : e.target.scrollTop;
                if(scrollTop > start) {
                    header.style.top = '-44px';
                    container.style.top = '0px';
                    header.style.opacity = '0.5';
                } else {
                    header.style.top = '0px';
                    container.style.top = '44px';
                    header.style.opacity = '1';
                }
                start = scrollTop;
                is_scrolling = false;
            },300);
        })(e);
    });
  };
})

.directive('scrollWatch3', function($rootScope) {
  return function(scope, elem, attr) {
    var start = 150, is_scrolling = false;
    var header = document.querySelector('.nav-bar-block[nav-bar="active"] ion-header-bar');
    if (!header) {
        header = document.querySelector('.nav-bar-block[nav-bar="entering"] ion-header-bar');
    }
    // var navcontainer = document.querySelector('ion-nav-view[name="menuContent"]');
    // document.querySelector('nav-bar-block[nav-bar="active"]').style.zIndex = '10';
    var container = document.querySelector('#tab-scroll-container .item.item-image');
    container.style.transition = 'opacity 0.55s ease';
    header.style.transition = 'top 0.25s ease, opacity 0.75s ease, backgrounds 0.75s ease';
    // navcontainer.style.zIndex = '9';
    elem.bind('scroll', function(e) {
        if (is_scrolling 
            // || !scope.showSubHeader
            ) {return;}
        is_scrolling = true;

        
        (function(e){
            setTimeout(function(){
                var scrollTop = (e.detail)?e.detail.scrollTop : e.target.scrollTop;
                if(scrollTop > start) {
                    header.style.top = '-44px';
                    header.style.background = 'none';
                    container.style.opacity = '0.5';
                    header.style.opacity = '0.5';
                } else {
                    header.style.top = '0px';
                    if (scrollTop > 200) {
                        header.style.background = 'rgba(255,255,255,1)';
                    } else {
                        header.style.background = 'none';

                    }
                    container.style.opacity = '1';
                    header.style.opacity = '1';
                }
                start = scrollTop;
                is_scrolling = false;
            },300);
        })(e);
    });
  };
})

.directive('ripple', function($rootScope) {
    return function(scope, currentElement, attr) {
        var onlongtouch; 
        var timer;
        if (currentElement[0].tagName == "ION-ITEM") {
            currentElement = angular.element(currentElement[0].querySelector(".item-content"));
        }
        var ink1 = angular.element(currentElement[0].querySelector(".ripple-ink"));

        if( !angular.isDefined(ink1) || ink1.length == 0 ) {
            ink1 = angular.element("<span class='ripple-ink'></span>");
            currentElement.prepend(ink1);
        }
        // currentElement.bind('click', makeInk);
        // currentElement.bind('tap', makeInk);
        currentElement.bind('touchstart', touchstart);
        currentElement.bind('touchend', touchend);
        function touchstart(e) {timer = setTimeout(makeInk.call(this,e), 500); }

        function touchend(e) {if (timer) clearTimeout(timer); }

        function makeInk(event) {
                var ink = angular.element(event.target.querySelector(".ripple-ink"));
                ink.removeClass("animate");

                if(!ink[0].offsetHeight && !ink[0].offsetWidth)
                {

                    d = Math.max(event.target.offsetWidth, event.target.offsetHeight);
                    ink.css("height", d + "px");
                    ink.css("width", d + "px");
                }
                if (event.type == 'click') {
                    x = event.offsetX - ink[0].offsetWidth / 2;
                    y = event.offsetY - ink[0].offsetHeight / 2;

                } else {
                    var rect = event.target.getBoundingClientRect();
                    var x = event.targetTouches[0].pageX - rect.left;
                    var y = event.targetTouches[0].pageY - rect.top;

                    x = x - ink[0].offsetWidth / 2;
                    y = y - ink[0].offsetHeight / 2;

                }

                ink.css("top", y +'px');
                ink.css("left", x +'px');
                ink.addClass("animate");  
        }
 
    };
})

function ImageListCtrl($log,$scope,$rootScope, $timeout, imageService, $ionicFilterBar, $ionicLoading) { 

    var vm = this,
        instance, 
        rowGridInit = false, 
        self = this,
        changeSearchCriteriaOrientation = true,
        isLoadMoreStart = false,
        sizes = [
            { columns: 3, gutter: 5 },
            { mq: '400px', columns: 3, gutter: 5 },
            { mq: '500px', columns: 4, gutter: 5 }
        ],
        // sizes = [
        //     { columns: 2, gutter: 0 },
        //     { mq: '400px', columns: 2, gutter: 0 },
        //     { mq: '500px', columns: 3, gutter: 0 }
        // ],
        previousCategotyId = 0;
    $rootScope.catrgories = ['all','fashion', 'nature', 'backgrounds', 'science', 'education', 'people', 'feelings', 'religion', 'health', 'places', 'animals', 'industry', 'food', 'computer', 'sports', 'transportation', 'travel', 'buildings', 'business', 'music'];

    vm.hasMoreImages = true;
    $scope.showSubHeader = true;

    vm.loadMore = loadMore;
    vm.doRefresh = doRefresh;

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.beforeEnter', function() {});
    $scope.$on('$ionicView.afterEnter', function() {
        // loadMore();
        $rootScope.showSearchCriteriaOrientation = true;
        $timeout(function(){
            $scope.$broadcast('acarousel.setitemactive', {id:3,display:'Backgrounds'});
            $scope.$emit('acarousel.setitemactive', {id:3,display:'Backgrounds'});
            $scope.$broadcast('a-carousel.arrayupdated', 'carousel');
        },1000 );
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    $scope.$on('imagelist_slided',function(event, slide_index) {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    $rootScope.toggleSearchCriteriaOrientation = function() {
        if (changeSearchCriteriaOrientation == false) {
            $rootScope.searchCriteria.orientation = 'horizontal';
            changeSearchCriteriaOrientation = true;
        } else{
            $rootScope.searchCriteria.orientation = 'vertical';
            changeSearchCriteriaOrientation = false;
        }
        doRefresh();
    };
    $rootScope.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: $rootScope.images,
        debounce:true,
        // favoritesEnabled:true,
        update: function (filteredItems) {
            if (filteredItems) {
                if (filteredItems.length < $rootScope.images.length) {
                    $rootScope.searchCriteria.page = 1;
                    $rootScope.images = filteredItems;
                    rowGridInit = false;
                    if (filteredItems.length > 0 ) {
                        $timeout(function(){
                            brickLoader();
                        },0);
                    }
                }
            }
        },
        cancel : function (items) {
            document.getElementById('sub-header').style.top = '44px';
            document.querySelector('[scroll-watch]').style.top = '88px';
            $scope.showSubHeader = true;
        },
        done: function(){
            $scope.showSubHeader = false;
            document.getElementById('sub-header').style.top = '0px';
            document.querySelector('[scroll-watch]').style.top = '44px';

        },
        filterProperties: 'tags'
      });
    }
    // ------carousel-----
        this.carouselOptions = {
                carouselId    : 'carousel',
                align         : 'center',
                selectFirst   : true,
                centerOnSelect: false,
                // template      : null
                template      : 'templates/carousel-template.html',
                maxScroll:0,
            };
        this.carouselData = getCatrgoryData();
        var is_selectFirst = true;
        this.onSelectCarousel = function (item) {
            var animationClass = "slide-in-smooth-", direction;
            // check for all
            if (is_selectFirst) {
                is_selectFirst = false;
                return;
            }
            $ionicLoading.show({
              template: '<ion-spinner></ion-spinner>'
            });
            console.log('Carousel item selected:', item);
            $rootScope.searchCriteria.category = $rootScope.catrgories[item.id];
            if (previousCategotyId > item.id) {
                direction = 'right';
            } else {
                direction = 'left';
            }
            doRefresh(function(){
                $ionicLoading.hide();
                if (direction == 'right') {
                    // document.getElementById("brick-container").classList.remove('slide-in-smooth-left');
                    // document.getElementById("brick-container").classList.add("slide-in-smooth-right");
                } else {
                    // document.getElementById("brick-container").classList.remove('slide-in-smooth-left');
                    // document.getElementById("brick-container").classList.add("slide-in-smooth-right");
                }
            });
            previousCategotyId = item.id;
        };
        function getCatrgoryData(randomImg) {
            randomImg = typeof randomImg === 'undefined' ? false : randomImg;

            var i, model, imgId, arr = [], total = $rootScope.catrgories.length;
            for (i = 0; i < total; i++) {
                model = {
                    id     : i,
                    display: $rootScope.catrgories[i].capitalizeFirstLetter()
                };
                if (randomImg) {
                    imgId     = Math.floor(Math.random() * 10000);
                    model.src = 'http://lorempixel.com/120/80/?' + imgId
                }
                arr.push(model);
            }

            return arr;
        }
    // -----------
    init();

    function init() {
        // Set Ink
        vm.images = [];
        vm.searchCriteria = {
            page : 1,
            orientation : 'all',
            editors_choice : false,
            order : 'popular',
            per_page : 12,
            image_type: 'all'
        };
    }
    function loadMore(cb) {
        if (isLoadMoreStart) {
            return;
        }
        isLoadMoreStart = true;
        vm.searchCriteria[$scope.tabCondition.key] = $scope.tabCondition.val;
        
        imageService
            .getImages(vm.searchCriteria)
            .then(function (result) {
                vm.searchCriteria.page += 1;
                vm.images = vm.images.concat(result);
            }, function (error) {
                vm.hasMoreImages = false;
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(items) {
                    calculateOnImageLoad(function(){
                        brickLoader();
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        isLoadMoreStart = false;
                        if (typeof cb == 'function') {
                            cb();
                        }
                    });
                },200);
            });
    }
    function brickLoader(){
        try{
            if (!rowGridInit) {
                instance = Bricks({
                   container: $scope.brickContainerSelector,
                   sizes: sizes,
                   packed: 'data-packed'
                })
                instance .resize(true);
                instance.pack();
                instance
                .on('pack',   () => console.log('ALL grid items packed.'))
                .on('update', () => console.log('NEW grid items packed.'))
                .on('resize', function (size) {$log.info(size);})
                rowGridInit = true;
                $log.info("#####--------init--------######");
            } else {
                
                    instance.update()
               
                $log.info("#####--------update--------######");
            }
        } catch (e){$log.info("#####--------brick error happen--------######");}
    }
    function doRefresh(cb) {
        rowGridInit = false;
        vm.searchCriteria.page = 1;
        vm.images = [];
        $timeout(function(){
            loadMore(cb);
        },0);
    }
    function calculateOnImageLoad(cb) {
        var currentlyLoaded = 0;

        var items = document.querySelectorAll($scope.brickContainerSelector + " > *:not([data-packed]) img"), 
            totalImg = items.length, 
            img;
        for (var i = 0; i < totalImg; i++) {
            img = items[i];
            
            (function(i) {
                if (img.complete) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                    return;
                }
                img.addEventListener("load", function(loadimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                });
                img.addEventListener("error", function(errorimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    items[i].parentNode.classList.add('error');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                });
            })(i);
        }
        function setOpacity1(){
            for (var i = 0; i < totalImg; i++) {
                items[i].style.opacity = 1;
                items[i].parentNode.classList.remove('loading');
            }
        }
    }
}
function ImageListCtrl1($log,$scope,$rootScope, $timeout, imageService, $ionicFilterBar, $ionicLoading) { 

    var vm = this,
        instance, 
        rowGridInit = false, 
        self = this,
        changeSearchCriteriaOrientation = true,
        isLoadMoreStart = false,
        sizes = [
            { columns: 3, gutter: 5 },
            { mq: '400px', columns: 3, gutter: 5 },
            { mq: '500px', columns: 4, gutter: 5 }
        ],
        // sizes = [
        //     { columns: 2, gutter: 0 },
        //     { mq: '400px', columns: 2, gutter: 0 },
        //     { mq: '500px', columns: 3, gutter: 0 }
        // ],
        previousCategotyId = 0;
    $rootScope.catrgories = ['all','fashion', 'nature', 'backgrounds', 'science', 'education', 'people', 'feelings', 'religion', 'health', 'places', 'animals', 'industry', 'food', 'computer', 'sports', 'transportation', 'travel', 'buildings', 'business', 'music'];

    $scope.hasMoreImages = true;
    $scope.showSubHeader = true;

    $scope.loadMore = loadMore;
    $scope.doRefresh = doRefresh;

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.beforeEnter', function() {});
    $scope.$on('$ionicView.afterEnter', function() {
        // loadMore();
        $rootScope.showSearchCriteriaOrientation = true;
        $timeout(function(){
            $scope.$broadcast('acarousel.setitemactive', {id:3,display:'Backgrounds'});
            $scope.$emit('acarousel.setitemactive', {id:3,display:'Backgrounds'});
            $scope.$broadcast('a-carousel.arrayupdated', 'carousel');
        },1000 );
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    $scope.$on('imagelist_slided',function(event, slide_index) {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    $rootScope.toggleSearchCriteriaOrientation = function() {
        if (changeSearchCriteriaOrientation == false) {
            $rootScope.searchCriteria.orientation = 'horizontal';
            changeSearchCriteriaOrientation = true;
        } else{
            $rootScope.searchCriteria.orientation = 'vertical';
            changeSearchCriteriaOrientation = false;
        }
        doRefresh();
    };
    $rootScope.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: $rootScope.images,
        debounce:true,
        // favoritesEnabled:true,
        update: function (filteredItems) {
            if (filteredItems) {
                if (filteredItems.length < $rootScope.images.length) {
                    $rootScope.searchCriteria.page = 1;
                    $rootScope.images = filteredItems;
                    rowGridInit = false;
                    if (filteredItems.length > 0 ) {
                        $timeout(function(){
                            brickLoader();
                        },0);
                    }
                }
            }
        },
        cancel : function (items) {
            document.getElementById('sub-header').style.top = '44px';
            document.querySelector('[scroll-watch]').style.top = '88px';
            $scope.showSubHeader = true;
        },
        done: function(){
            $scope.showSubHeader = false;
            document.getElementById('sub-header').style.top = '0px';
            document.querySelector('[scroll-watch]').style.top = '44px';

        },
        filterProperties: 'tags'
      });
    }
    // ------carousel-----
        this.carouselOptions = {
                carouselId    : 'carousel',
                align         : 'center',
                selectFirst   : true,
                centerOnSelect: false,
                // template      : null
                template      : 'templates/carousel-template.html',
                maxScroll:0,
            };
        this.carouselData = getCatrgoryData();
        var is_selectFirst = true;
        this.onSelectCarousel = function (item) {
            var animationClass = "slide-in-smooth-", direction;
            // check for all
            if (is_selectFirst) {
                is_selectFirst = false;
                return;
            }
            $ionicLoading.show({
              template: '<ion-spinner></ion-spinner>'
            });
            console.log('Carousel item selected:', item);
            $rootScope.searchCriteria.category = $rootScope.catrgories[item.id];
            if (previousCategotyId > item.id) {
                direction = 'right';
            } else {
                direction = 'left';
            }
            doRefresh(function(){
                $ionicLoading.hide();
                if (direction == 'right') {
                    // document.getElementById("brick-container").classList.remove('slide-in-smooth-left');
                    // document.getElementById("brick-container").classList.add("slide-in-smooth-right");
                } else {
                    // document.getElementById("brick-container").classList.remove('slide-in-smooth-left');
                    // document.getElementById("brick-container").classList.add("slide-in-smooth-right");
                }
            });
            previousCategotyId = item.id;
        };
        function getCatrgoryData(randomImg) {
            randomImg = typeof randomImg === 'undefined' ? false : randomImg;

            var i, model, imgId, arr = [], total = $rootScope.catrgories.length;
            for (i = 0; i < total; i++) {
                model = {
                    id     : i,
                    display: $rootScope.catrgories[i].capitalizeFirstLetter()
                };
                if (randomImg) {
                    imgId     = Math.floor(Math.random() * 10000);
                    model.src = 'http://lorempixel.com/120/80/?' + imgId
                }
                arr.push(model);
            }

            return arr;
        }
    // -----------
    init();

    function init() {
        // Set Ink
        $scope.images = [];
        $scope.searchCriteria = {
            page : 1,
            orientation : 'all',
            editors_choice : false,
            order : 'popular',
            per_page : 12,
            image_type: 'all'
        };
    }
    function loadMore(cb) {
        if (isLoadMoreStart) {
            return;
        }
        isLoadMoreStart = true;
        $scope.searchCriteria[$scope.tabCondition.key] = $scope.tabCondition.val;
        
        imageService
            .getImages($scope.searchCriteria)
            .then(function (result) {
                $scope.searchCriteria.page += 1;
                $scope.images = $scope.images.concat(result);
            }, function (error) {
                $scope.hasMoreImages = false;
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(items) {
                    calculateOnImageLoad(function(){
                        brickLoader();
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        isLoadMoreStart = false;
                        if (typeof cb == 'function') {
                            cb();
                        }
                    });
                },200);
            });
    }
    function brickLoader(){
        try{
            if (!rowGridInit) {
                instance = Bricks({
                   container: $scope.brickContainerSelector,
                   sizes: sizes,
                   packed: 'data-packed'
                })
                instance .resize(true);
                instance.pack();
                instance
                .on('pack',   () => console.log('ALL grid items packed.'))
                .on('update', () => console.log('NEW grid items packed.'))
                .on('resize', function (size) {$log.info(size);})
                rowGridInit = true;
                $log.info("#####--------init--------######");
            } else {
                
                    instance.update()
               
                $log.info("#####--------update--------######");
            }
        } catch (e){$log.info("#####--------brick error happen--------######");}
    }
    function doRefresh(cb) {
        rowGridInit = false;
        $scope.searchCriteria.page = 1;
        $scope.images = [];
        $timeout(function(){
            loadMore(cb);
        },0);
    }
    function calculateOnImageLoad(cb) {
        var currentlyLoaded = 0;

        var items = document.querySelectorAll($scope.brickContainerSelector + " > *:not([data-packed]) img"), 
            totalImg = items.length, 
            img;
        for (var i = 0; i < totalImg; i++) {
            img = items[i];
            
            (function(i) {
                if (img.complete) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                    return;
                }
                img.addEventListener("load", function(loadimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                });
                img.addEventListener("error", function(errorimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    items[i].parentNode.classList.add('error');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                });
            })(i);
        }
        function setOpacity1(){
            for (var i = 0; i < totalImg; i++) {
                items[i].style.opacity = 1;
                items[i].parentNode.classList.remove('loading');
            }
        }
    }
}

function ImageListCtrlBCk($log,$scope,$rootScope, $timeout, imageService, $ionicFilterBar, $ionicLoading) { 

    var vm = this,
        instance, 
        rowGridInit = false, 
        self = this,
        changeSearchCriteriaOrientation = true,
        isLoadMoreStart = false,
        sizes = [
            { columns: 3, gutter: 5 },
            { mq: '400px', columns: 3, gutter: 5 },
            { mq: '500px', columns: 4, gutter: 5 }
        ],
        previousCategotyId = 0;
        

    $scope.hasMoreImages = true;
    $scope.showSubHeader = true;

    this.loadMore = loadMore;
    this.doRefresh = doRefresh;

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.beforeEnter', function() {});
    $scope.$on('$ionicView.afterEnter', function() {
        // loadMore();
        $rootScope.showSearchCriteriaOrientation = true;
        $timeout(function(){
        $scope.$broadcast('acarousel.setitemactive', {id:3,display:'Backgrounds'});
        $scope.$emit('acarousel.setitemactive', {id:3,display:'Backgrounds'});
        $scope.$broadcast('a-carousel.arrayupdated', 'carousel');
    },1000 );
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    $rootScope.toggleSearchCriteriaOrientation = function() {
        if (changeSearchCriteriaOrientation == false) {
            $rootScope.searchCriteria.orientation = 'horizontal';
            changeSearchCriteriaOrientation = true;
        } else{
            $rootScope.searchCriteria.orientation = 'vertical';
            changeSearchCriteriaOrientation = false;
        }
        doRefresh();
    };
    $rootScope.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: $rootScope.images,
        debounce:true,
        // favoritesEnabled:true,
        update: function (filteredItems) {
            if (filteredItems) {
                if (filteredItems.length < $rootScope.images.length) {
                    $rootScope.searchCriteria.page = 1;
                    $rootScope.images = filteredItems;
                    rowGridInit = false;
                    if (filteredItems.length > 0 ) {
                        $timeout(function(){
                            brickLoader();
                        },0);
                    }
                }
            }
        },
        cancel : function (items) {
            document.getElementById('sub-header').style.top = '44px';
            document.querySelector('[scroll-watch]').style.top = '88px';
            $scope.showSubHeader = true;
        },
        done: function(){
            $scope.showSubHeader = false;
            document.getElementById('sub-header').style.top = '0px';
            document.querySelector('[scroll-watch]').style.top = '44px';

        },
        filterProperties: 'tags'
      });
    }
    // ------carousel-----
        this.carouselOptions = {
                carouselId    : 'carousel',
                align         : 'center',
                selectFirst   : true,
                centerOnSelect: false,
                // template      : null
                template      : 'templates/carousel-template.html',
                maxScroll:0,
            };
        this.carouselData = getCatrgoryData();
        var is_selectFirst = true;
        this.onSelectCarousel = function (item) {
            var animationClass = "slide-in-smooth-", direction;
            // check for all
            if (is_selectFirst) {
                is_selectFirst = false;
                return;
            }
            // $ionicLoading.show({
            //   template: '<ion-spinner></ion-spinner>'
            // });
            console.log('Carousel item selected:', item);
            $rootScope.searchCriteria.category = $rootScope.catrgories[item.id];
            if (previousCategotyId > item.id) {
                direction = 'right';
            } else {
                direction = 'left';
            }
            doRefresh(function(){
                // $ionicLoading.hide();
                if (direction == 'right') {
                    // document.getElementById("brick-container").classList.remove('slide-in-smooth-left');
                    // document.getElementById("brick-container").classList.add("slide-in-smooth-right");
                } else {
                    // document.getElementById("brick-container").classList.remove('slide-in-smooth-left');
                    // document.getElementById("brick-container").classList.add("slide-in-smooth-right");
                }
            });
            previousCategotyId = item.id;
        };
        function getCatrgoryData(randomImg) {
            randomImg = typeof randomImg === 'undefined' ? false : randomImg;

            var i, model, imgId, arr = [], total = $rootScope.catrgories.length;
            for (i = 0; i < total; i++) {
                model = {
                    id     : i,
                    display: $rootScope.catrgories[i].capitalizeFirstLetter()
                };
                if (randomImg) {
                    imgId     = Math.floor(Math.random() * 10000);
                    model.src = 'http://lorempixel.com/120/80/?' + imgId
                }
                arr.push(model);
            }

            return arr;
        }
    // -----------
    init();

    function init() {
        // Set Ink
    }
    function loadMore(cb) {
        if (isLoadMoreStart) {
            return;
        }
        isLoadMoreStart = true;
        imageService
            .getImages($rootScope.searchCriteria)
            .then(function (result) {
                $rootScope.searchCriteria.page += 1;
                $rootScope.images = $rootScope.images.concat(result);
            }, function (error) {
                $scope.hasMoreImages = false;
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(items) {
                    calculateOnImageLoad(function(){
                        brickLoader();
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        isLoadMoreStart = false;
                        if (typeof cb == 'function') {
                            cb();
                        }
                    });
                },200);
            });
    }
    function brickLoader(){
        try{
            if (!rowGridInit) {
                instance = Bricks({
                   container: '#brick-container',
                   sizes: sizes,
                   packed: 'data-packed'
                })
                instance .resize(true);
                instance.pack();
                instance
                .on('pack',   () => console.log('ALL grid items packed.'))
                .on('update', () => console.log('NEW grid items packed.'))
                .on('resize', function (size) {$log.info(size);})
                rowGridInit = true;
                $log.info("#####--------init--------######");
            } else {
                
                    instance.update()
               
                $log.info("#####--------update--------######");
            }
        } catch (e){$log.info("#####--------brick error happen--------######");}
    }
    function doRefresh(cb) {
        rowGridInit = false;
        $rootScope.searchCriteria.page = 1;
        $rootScope.images = [];
        $timeout(function(){
            loadMore(cb);
        },0);
    }
    function calculateOnImageLoad(cb) {
        var currentlyLoaded = 0;

        var items = document.querySelectorAll("#brick-container > *:not([data-packed]) img"), 
            totalImg = items.length, 
            img;
        for (var i = 0; i < totalImg; i++) {
            img = items[i];
            
            (function(i) {
                if (img.complete) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                    return;
                }
                img.addEventListener("load", function(loadimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                });
                img.addEventListener("error", function(errorimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    items[i].parentNode.classList.add('error');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                });
            })(i);
        }
        function setOpacity1(){
            for (var i = 0; i < totalImg; i++) {
                items[i].style.opacity = 1;
                items[i].parentNode.classList.remove('loading');
            }
        }
    }
}


function CategoryCtrl($log,$scope,$rootScope, $timeout, imageService, $ionicFilterBar, $ionicLoading, $state) {

        var cat_name,
            vm = this;

        vm.catImages = {};
        vm.hasMoreImages = {};
        vm.carouselOptions = {};
        vm.onSelectCarousel = function(){

        }
        vm.showMore = showMore;

        for(var i=1; i < $rootScope.catrgories.length ; i++){
            cate_name = $rootScope.catrgories[i];
            vm.hasMoreImages[cate_name] = true;
            vm.catImages[cate_name] = [];
            /*vm.catImages[cate_name] = [
                {
                    "previewHeight":84,
                    "likes":64,
                    "favorites":62,
                    "tags":"yellow, natural, flower",
                    "webformatHeight":360,
                    "views":17397,
                    "webformatWidth":640,
                    "previewWidth":150,
                    "comments":11,
                    "downloads":9366,
                    "pageURL":"https://pixabay.com/en/yellow-natural-flower-715540/",
                    "previewURL":"https://pixabay.com/static/uploads/photo/2015/04/10/00/41/yellow-715540_150.jpg",
                    "webformatURL":"https://pixabay.com/get/ee34b40a2cf41c2ad65a5854e44f4f92e77febc818b5174090f1c678a6ea_640.jpg",
                    "imageWidth":3020,
                    "user_id":916237,
                    "user":"Wow_Pho",
                    "type":"photo",
                    "id":715540,
                    "userImageURL":"https://pixabay.com/static/uploads/user/2015/04/07/14-10-15-590_250x250.jpg",
                    "imageHeight":1703
                },
                {
                    "previewHeight":83,
                    "likes":63,
                    "favorites":41,
                    "tags":"rose, flower, yellow",
                    "webformatHeight":355,
                    "views":16462,
                    "webformatWidth":640,
                    "previewWidth":150,
                    "comments":15,
                    "downloads":3625,
                    "pageURL":"https://pixabay.com/en/rose-flower-yellow-yellow-rose-113735/",
                    "previewURL":"https://pixabay.com/static/uploads/photo/2013/05/26/12/14/rose-113735_150.jpg",
                    "webformatURL":"https://pixabay.com/get/e834b2082bf11c2ad65a5854e44f4f92e77febc818b5174090f1c678a6ea_640.jpg",
                    "imageWidth":2410,
                    "user_id":817,
                    "user":"blizniak",
                    "type":"photo",
                    "id":113735,
                    "userImageURL":"https://pixabay.com/static/uploads/user/2013/06/28/17-07-05-714_250x250.jpg",
                    "imageHeight":1337
                },
                {
                    "previewHeight":99,
                    "likes":64,
                    "favorites":71,
                    "tags":"yellow, flower, wood",
                    "webformatHeight":426,
                    "views":14382,
                    "webformatWidth":640,
                    "previewWidth":150,
                    "comments":17,
                    "downloads":6910,
                    "pageURL":"https://pixabay.com/en/yellow-flower-wood-370256/",
                    "previewURL":"https://pixabay.com/static/uploads/photo/2014/06/17/07/21/yellow-370256_150.jpg",
                    "webformatURL":"https://pixabay.com/get/ea32b10d2df21c2ad65a5854e44f4f92e77febc818b5174090f1c678a6ea_640.jpg",
                    "imageWidth":5184,
                    "user_id":299467,
                    "user":"elektrosmart",
                    "type":"photo",
                    "id":370256,
                    "userImageURL":"https://pixabay.com/static/uploads/user/2014/06/18/11-30-30-400_250x250.jpg",
                    "imageHeight":3456
                },
                {
                    "previewHeight":99,
                    "likes":5,
                    "favorites":4,
                    "tags":"girl, butterfly, dreaming",
                    "webformatHeight":426,
                    "views":198,
                    "webformatWidth":640,
                    "previewWidth":150,
                    "comments":0,
                    "downloads":110,
                    "pageURL":"https://pixabay.com/en/girl-butterfly-dreaming-camp-1319108/",
                    "previewURL":"https://pixabay.com/static/uploads/photo/2016/04/09/23/10/girl-1319108_150.jpg",
                    "webformatURL":"https://pixabay.com/get/e836b00629f4093ed95c4518b74e459fe773eadc04b0154794f5c07ea6ecb2_640.jpg",
                    "imageWidth":4272,
                    "user_id":485024,
                    "user":"AdinaVoicu",
                    "type":"photo",
                    "id":1319108,
                    "userImageURL":"https://pixabay.com/static/uploads/user/2016/04/20/19-14-13-58_250x250.jpg",
                    "imageHeight":2848
                }
            ];*/
            vm.carouselOptions[cate_name] = {
                carouselId    : 'carousel-' + cate_name,
                align         : 'left',
                selectFirst   : false,
                centerOnSelect: false,
                template      : 'templates/demo-3.html',
                pullRefresh   : {
                    active  : true,
                    // callBack: new PullRefreshFactory(cate_name)
                    callBack: pullRefresh
                }
            };
            PullRefreshFactory(cate_name);
        }

        // Pull refresgh method for carousel 6
        function pullRefresh() {
            $timeout(function () {
                
            vm.catImages1= vm.catImages1.concat(
                [
                    {
                        "previewHeight":99,
                        "likes":11,
                        "favorites":2,
                        "tags":"flower, blossom, bloom",
                        "webformatHeight":426,
                        "views":2005,
                        "webformatWidth":640,
                        "previewWidth":150,
                        "comments":0,
                        "downloads":462,
                        "pageURL":"https://pixabay.com/en/flower-blossom-bloom-yellow-close-302869/",
                        "previewURL":"https://pixabay.com/static/uploads/photo/2014/04/02/00/30/flower-302869_150.jpg",
                        "webformatURL":"https://pixabay.com/get/ea35b3072efd1c2ad65a5854e44f4f92e77febc818b5174090f1c678a6ea_640.jpg",
                        "imageWidth":6000,
                        "user_id":48777,
                        "user":"Josch13",
                        "type":"photo",
                        "id":302869,
                        "userImageURL":"https://pixabay.com/static/uploads/user/2013/11/05/02-10-23-764_250x250.jpg",
                        "imageHeight":4000
                    },
                    {
                        "previewHeight":99,
                        "likes":78,
                        "favorites":88,
                        "tags":"summer still-life, daisies, yellow",
                        "webformatHeight":426,
                        "views":15868,
                        "webformatWidth":640,
                        "previewWidth":150,
                        "comments":24,
                        "downloads":8925,
                        "pageURL":"https://pixabay.com/en/summer-still-life-daisies-yellow-779386/",
                        "previewURL":"https://pixabay.com/static/uploads/photo/2015/05/22/17/22/summer-still-life-779386_150.jpg",
                        "webformatURL":"https://pixabay.com/get/ee32b80c20f21c2ad65a5854e44f4f92e77febc818b5174090f1c678a6ea_640.jpg",
                        "imageWidth":5760,
                        "user_id":334088,
                        "user":"jill111",
                        "type":"photo",
                        "id":779386,
                        "userImageURL":"https://pixabay.com/static/uploads/user/2016/04/21/14-13-05-388_250x250.jpg",
                        "imageHeight":3840
                    },
                    {
                        "previewHeight":99,
                        "likes":55,
                        "favorites":35,
                        "tags":"tulips, cut flowers, flower basket",
                        "webformatHeight":426,
                        "views":13463,
                        "webformatWidth":640,
                        "previewWidth":150,
                        "comments":17,
                        "downloads":5011,
                        "pageURL":"https://pixabay.com/en/tulips-cut-flowers-flower-basket-708410/",
                        "previewURL":"https://pixabay.com/static/uploads/photo/2015/04/05/19/28/tulips-708410_150.jpg",
                        "webformatURL":"https://pixabay.com/get/ee35b90b29f41c2ad65a5854e44f4f92e77febc818b5174090f1c678a6ea_640.jpg",
                        "imageWidth":6000,
                        "user_id":526143,
                        "user":"Pezibear",
                        "type":"photo",
                        "id":708410,
                        "userImageURL":"https://pixabay.com/static/uploads/user/2016/02/11/19-21-18-242_250x250.jpg",
                        "imageHeight":4000
                    }
                ])
                $scope.$broadcast('a-carousel.arrayupdated', 'carousel-fashion');
                $scope.$broadcast('a-carousel.pullrefresh.done');
            }, 2500);
        }
        function PullRefreshFactory(category) {
            var t = this;
            t.category = category;
            t.page = 1;
            // return 
            (function(){
                console.log("-----ohhhhhhhhhhhhhhhh------------")
                if (!vm.hasMoreImages[t.category]) {
                    // $scope.$broadcast('a-carousel.arrayupdated', 'carousel-' + t.category);
                    // $scope.$broadcast('a-carousel.pullrefresh.done');
                    return;
                }
                loadMoreByCategory(t.category, t.page, function(){
                    // t.page ++ ;
                    // $scope.$broadcast('a-carousel.arrayupdated', 'carousel-' + t.category);
                    // $scope.$broadcast('a-carousel.pullrefresh.done');
                })
            })();
        }

        function loadMoreByCategory(category, page, cb) {
            // if (isLoadMoreStart) {
            //     return;
            // }
            var searchCriteria = $rootScope.searchCriteria;
            searchCriteria.category = category;
            searchCriteria.page = page;
            searchCriteria.per_page = 6;
            imageService
                .getImages(searchCriteria)
                .then(function (result) {
                    vm.catImages[category] = vm.catImages[category].concat(result);
                }, function (error) {
                    vm.hasMoreImages[cate_name] = false;
                    console.log(error);
                })
                .finally(function(result){
                    if (typeof cb == 'function') {
                        cb();
                    }
                });
        }

        $scope.hehescroll = function(argument) {
            // console.log(argument);
        }
        $scope.$on('$ionicView.afterEnter', function() {
         calculateOnImageLoad();
     });
       
    function calculateOnImageLoad(cb) {
        var currentlyLoaded = 0;
        var imgContainers = document.querySelectorAll(".category-img .category-scroll-x");
        for (var j = 0; j < imgContainers.length; j++) {

            var items = imgContainers[j].querySelectorAll("img"), 
                totalImg = items.length, 
                img, container_width = 0;
                (function(container_width, currentlyLoaded){

                    for (var i = 0; i < totalImg; i++) {
                        img = items[i];
                        
                        (function(img, container, totalImg) {
                            if (img.complete) {
                                currentlyLoaded++;
                                container_width += img.clientWidth;
                                if (currentlyLoaded == totalImg) {
                                    if (typeof cb == 'function') {
                                        cb();
                                    }
                                    container.style.width = 2 + container_width + "px";
                                }
                                // container.style.width = container.clientWidth + img.clientWidth + "px";
                                return;
                            }
                            img.addEventListener("load", function(loadimg) {
                                currentlyLoaded++;
                                container_width += img.clientWidth;
                                if (currentlyLoaded == totalImg) {
                                    if (typeof cb == 'function') {
                                        cb();
                                    }

                                    container.style.width = 2 + container_width + "px";
                                    // setOpacity1();
                                }
                                // container.style.width = container.clientWidth + img.clientWidth + "px";
                            });
                            img.addEventListener("error", function(errorimg) {
                                currentlyLoaded++;
                                img.style.display = "none";
                                if (currentlyLoaded == totalImg) {
                                    if (typeof cb == 'function') {
                                        cb();
                                    }
                                }
                            });
                        })(img, imgContainers[j], totalImg);
                    }


                })(container_width, currentlyLoaded);
            // break;
        }
    }

    function showMore(category){
        $rootScope.searchCriteria.category = category;
        $state.go('app.brickfs');
    }
}



// Returns a function, that, as long as it continues to be invoked, will not
// be triggered. The function will be called after it stops being called for
// N milliseconds. If `immediate` is passed, trigger the function on the
// leading edge, instead of the trailing.
function debounce(func, wait, immediate) {
    var timeout;
    return function() {
        var context = this, args = arguments;
        var later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};


// var myEfficientFn = debounce(function() {
//     // All the taxing stuff you do
// }, 250);

// window.addEventListener('resize', myEfficientFn);
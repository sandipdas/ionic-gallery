// Ionic Starter App
// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'ionic.service.core', 'ionic.service.analytics', 'starter.controllers', 'ionic-material', 'starter.services', 'ionic-native-transitions'])

.run(function($ionicPlatform, $ionicAnalytics) {
    $ionicPlatform.ready(function() {
        $ionicAnalytics.register();
        var push = new Ionic.Push({
            "debug": true
        });
        push.register(function(token) {
            console.log("Device token:", token.token);
        });
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);
        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }
    });
}).config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider, $ionicFilterBarConfigProvider, $ionicNativeTransitionsProvider) {
    // Turn off caching for demo simplicity's sake
    $ionicConfigProvider.views.maxCache(7);
    $ionicConfigProvider.scrolling.jsScrolling(false);
    $ionicNativeTransitionsProvider.setDefaultOptions({
        "duration"          : 300,
        "androiddelay"      : 100, // Longer delay better for older androids
        // "fixedPixelsTop"    : 64, // looks OK on iOS
    });
     $ionicNativeTransitionsProvider.setDefaultTransition({
        type: 'slide',
        direction: 'right'
    });
     $ionicNativeTransitionsProvider.setDefaultBackTransition({
        type: 'slide',
        direction: 'left'
    });
    $ionicFilterBarConfigProvider.transition("horizontal");
    $stateProvider.state('home', {
        url: '/home',
        templateUrl: 'home.html'
    })


    .state('app', {
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
    })

    .state('app.search', {
        url: '/search',
        views: {
            'menuContent': {
                templateUrl: 'templates/search.html'
            }
        }
    })

    /*.state('app.browse', {
        url: '/browse',
        views: {
            'menuContent': {
                templateUrl: 'templates/browse.html',
                controller: 'BrowseCtrl'
            }
        }
    })

    */

    .state('app.macy', {
        url: '/macy',
        views: {
            'menuContent': {
                templateUrl: 'templates/macy.html',
                controller: 'macyCtrl'
            }
        }
    })

    .state('app.brick', {
        url: '/brick',
        views: {
            'menuContent': {
                templateUrl: 'templates/brick.html',
                controller: 'brickCtrl',
                controllerAs: 'brick'
            },
            fabContent:{
                template: '<ion-view> <ion-content><div id="carousel-menu"> <a-carousel carousel-options="::brick.carouselOptions"array-provider="::brick.carouselData"on-select="brick.onSelectCarousel(item)"> </a-carousel> </div></ion-view> </ion-content>',
                controller:function (){
                        // ------carousel-----
                        this.carouselOptions = {
                                carouselId    : 'carousel-menu',
                                align         : 'left',
                                selectFirst   : true,
                                centerOnSelect: false,
                                // template      : null
                                template      : 'templates/carousel-template.html'
                            };
                        this.carouselData = createArray(8);
                        this.onSelectCarousel = function (item) {
                                console.log('Carousel item selected:', item);
                            };
                        function createArray(total, randomImg) {
                            randomImg                = typeof randomImg === 'undefined' ? false : randomImg;
                            var i, model, imgId, arr = [];
                            for (i = 0; i < total; i++) {
                                model = {
                                    id     : i,
                                    display: 'item ' + i
                                };
                                if (i === 2 || i === 13) {
                                    model.display = 'longer ' + model.display;
                                }
                                if (randomImg) {
                                    imgId     = Math.floor(Math.random() * 10000);
                                    model.src = 'http://lorempixel.com/120/80/?' + imgId
                                }
                                arr.push(model);
                            }

                            return arr;
                        }
                        // -----------
                },
                controllerAs: 'brick'
            }
        }
    })


    .state('app.grid', {
        url: '/grid',
        views: {
            'menuContent': {
                templateUrl: 'templates/grid.html',
                controller: 'gridCtrl'
            },
            'fabContent': {
                template: '<button id="upload-image" class="button button-fab button-fab-bottom-right expanded button-assertive flap"><i class="icon ion-ios-upload-outline"></i></button>',
                
            }
        }
    })

    .state('app.masonry', {
        url: '/masonry',
        views: {
            'menuContent': {
                templateUrl: 'templates/masonry.html',
                controller: 'DemoCtrl'
            }
        }
    })

    .state('app.image', {
        url: '/image/:id',
        views: {
            'menuContent': {
                templateUrl: 'templates/image.html',
                controller: 'imageCtrl'
            },
            'fabContent': {
                template: ''
            }
        }
    })

    .state('app.playlists', {
        url: '/playlists',
        views: {
            'menuContent': {
                templateUrl: 'templates/playlists.html',
                controller: 'PlaylistsCtrl'
            }
        }
    })

    .state('app.single', {
        url: '/playlists/:playlistId',
        views: {
            'menuContent': {
                templateUrl: 'templates/playlist.html',
                controller: 'PlaylistCtrl'
            }
        }
    })

    .state('app.dash', {
        url: '/dash',
        views: {
            'menuContent': {
                templateUrl: 'templates/dash.html',
                controller: 'DashCtrl'
            }
        }
    });
    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/brick');
});
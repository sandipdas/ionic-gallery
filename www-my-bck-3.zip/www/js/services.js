
(function() {
    'use strict';



	angular
		.module('starter.services', [])
		.service('ApiSettings', ApiSettings);

	ApiSettings.$inject = [];
	
	function ApiSettings(){
		this.getBaseUrl = 'https://pixabay.com/api/?key=2394489-de1617b68ca9029fee4278f39';
	}


    angular
        .module('starter.services')
        .factory('imageService', imageService);

    imageService.$inject = ["$http","$q", "ApiSettings"];

    /* @ngInject */
    function imageService($http, $q, ApiSettings) {
		init();
        var service = {
            getImages: getImages
        };
        return service;

        ////////////////

		function init() {
			
		}

        function getImagesOld(page, limit) {
			var deferred = $q.defer();
	        setTimeout(function(items) {
			    deferred.resolve(loadImg(page, limit));
	        },2000);
			return deferred.promise;
        }

        function getImages(searchCriteria) {
			var deferred = $q.defer();
			var url = ApiSettings.getBaseUrl;
			angular.forEach(searchCriteria, function(val, key){
				url += '&' + key + '=' + val;
			});
	        // $http.get('/data/images.json')
	        $http.get(url)
				.then(function (result) {
					deferred.resolve(result.data.hits);
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
        }

	    function loadImg(page, limit) {
	        var rand_size = [{
	                'w': 480,
	                'h': 885
	            }, {
	                'w': 360,
	                'h': 640
	            }, {
	                'w': 960,
	                'h': 640
	            }, {
	                'w': 425,
	                'h': 590
	            }],
	            w, h, images = [];
	        for (var i = page * limit; i < (page + 1) * limit; i++) {
	            w = rand_size[parseInt(Math.random() * 100 % 4)].w;
	            h = rand_size[parseInt(Math.random() * 100 % 4)].h;
	            images.push({
	                // 'src': 'http://unsplash.it/' + w + '/' + h + '?image=' + i
	                'src': 'http://unsplash.it/300?image=' + i,

	            });
	        }
	        return images;
	    }
	    
    }
})();

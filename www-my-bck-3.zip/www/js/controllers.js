angular.module('starter.controllers', ['jett.ionic.filter.bar', 'aCarousel'])

.controller('AppCtrl', function($rootScope, $scope, $ionicModal, $timeout,$state, ionicMaterialInk, ionicMaterialMotion) {


        initImagesSettings();

    function initImagesSettings(argument) {
        $rootScope.images = [];
        $rootScope.searchCriteria = {
            page : 1,
            orientation : 'all',
            editors_choice : false,
            order : 'popular',
            per_page : 12,
            image_type: 'all'
        };
        $scope.showSearchCriteriaOrientation = true;

    }





    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //$scope.$on('$ionicView.enter', function(e) {
    //});
    // Form data for the login modal
    $scope.loginData = {};
    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/login.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    // Open the login modal
    $scope.login = function() {
        $scope.modal.show();
    };
    // Perform the login action when the user submits the login form
    $scope.doLogin = function() {
        console.log('Doing login', $scope.loginData);
        // Simulate a login delay. Remove this and replace with your login
        // code if using a login system
        $timeout(function() {
            $scope.closeLogin();
        }, 1000);
    };

    // ---------for material look------------
    // (function(){
        $scope.isExpanded = false;
        $scope.hasHeaderFabLeft = false;
        $scope.hasHeaderFabRight = false;

        var navIcons = document.getElementsByClassName('ion-navicon'), navIconsLength = navIcons.length;
        for (var i = 0; i < navIconsLength; i++) {
            navIcons[i].addEventListener('click', function() {
                this.classList.toggle('active');
            });
        }

        ////////////////////////////////////////
        // Layout Methods
        ////////////////////////////////////////

        $scope.hideNavBar = function() {
            document.getElementsByTagName('ion-nav-bar')[0].style.display = 'none';
        };

        $scope.showNavBar = function() {
            document.getElementsByTagName('ion-nav-bar')[0].style.display = 'block';
        };

        $scope.noHeader = function() {
            var content = document.getElementsByTagName('ion-content');
            for (var i = 0; i < content.length; i++) {
                if (content[i].classList.contains('has-header')) {
                    content[i].classList.toggle('has-header');
                }
            }
        };

        $scope.setExpanded = function(bool) {
            $scope.isExpanded = bool;
        };

        $scope.setHeaderFab = function(location) {
            var hasHeaderFabLeft = false;
            var hasHeaderFabRight = false;

            switch (location) {
                case 'left':
                    hasHeaderFabLeft = true;
                    break;
                case 'right':
                    hasHeaderFabRight = true;
                    break;
            }

            $scope.hasHeaderFabLeft = hasHeaderFabLeft;
            $scope.hasHeaderFabRight = hasHeaderFabRight;
        };

        $scope.hasHeader = function() {
            var content = document.getElementsByTagName('ion-content');
            for (var i = 0; i < content.length; i++) {
                if (!content[i].classList.contains('has-header')) {
                    content[i].classList.toggle('has-header');
                }
            }

        };

        $scope.hideHeader = function() {
            $scope.hideNavBar();
            $scope.noHeader();
        };

        $scope.showHeader = function() {
            $scope.showNavBar();
            $scope.hasHeader();
        };

        $scope.clearFabs = function() {
            var fabs = document.getElementsByClassName('button-fab');
            if (fabs.length && fabs.length > 1) {
                fabs[0].remove();
            }
        };


        // Delay expansion
        $timeout(function() {
            // $scope.isExpanded = true;
        // Set Motion
        // ionicMaterialMotion.fadeSlideInRight();


        }, 300);


        ionicMaterialMotion.ripple();
        // Set Ink
        ionicMaterialInk.displayEffect();

    // })();



    function doOnOrientationChange()
    {
        switch(window.orientation) 
        {  
            case -90:
            case 90:
                // alert('landscape');
                $rootScope.orientation = 'landscape';
                break; 
            default:
                $rootScope.orientation = 'portrait';
                // alert('portrait');
            break; 
        }
    }

    window.addEventListener('orientationchange', doOnOrientationChange);
    $scope.navBarTransparent = false;
    $scope.displaySearchButton = true;
})

// -------
    .controller('PlaylistsCtrl', function($scope) {
        $scope.playlists = [{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        },{
            title: 'Reggae',
            id: 1
        }, {
            title: 'Chill',
            id: 2
        }, {
            title: 'Dubstep',
            id: 3
        }, {
            title: 'Indie',
            id: 4
        }, {
            title: 'Rap',
            id: 5
        }, {
            title: 'Cowbell',
            id: 6
        }];
            $scope.$on('$ionicView.loaded', function() { //This just one when leaving, which happens when I logout
            console.log("App view (menu) loaded.");
            console.log(arguments);
        });
        $scope.$on('$ionicView.beforeEnter', function() { //This just one when leaving, which happens when I logout
            console.log("App view (menu) beforeEnter.");
            console.log(arguments);
        });
        $scope.$on('$ionicView.beforeLeave', function() { //This just one when leaving, which happens when I logout
            console.log("App view (menu) beforeLeave.");
            console.log(arguments);
        });
        $scope.$on('$ionicView.afterEnter', function() { //This just one when leaving, which happens when I logout
            console.log("App view (menu) afterEnter.");
            console.log(arguments);
        });
        $scope.$on('$ionicView.afterLeave', function() { //This just one when leaving, which happens when I logout
            console.log("App view (menu) afterLeave.");
            console.log(arguments);
        });
        $scope.$on('$ionicView.unloaded', function() { //This just one when leaving, which happens when I logout
            console.log("App view (menu) unloaded.");
            console.log(arguments);
        });
        document.addEventListener('DOMContentLoaded', function() {});
    })

    .controller('PlaylistCtrl', function($scope, $ionicActionSheet, $ionicModal, $ionicBackdrop, $ionicLoading, $timeout, $http, $stateParams) {
        $scope.showActionSheet = function() {
            // Show the action sheet
            var hideSheet = $ionicActionSheet.show({
                buttons: [{
                    text: '<b>Share</b> This'
                }, {
                    text: 'Move'
                }],
                destructiveText: 'Delete',
                titleText: 'Modify your album',
                cancelText: 'Cancel',
                cancel: function() {
                    // add cancel code..
                },
                buttonClicked: function(index) {
                    return true;
                }
            });
            // For example's sake, hide the sheet after two seconds
            //  $timeout(function() {
            // hideSheet();
            //  }, 20000);
        };
        $scope.showBackDrop = function() {
            $ionicBackdrop.retain();
            $timeout(function() {
                $ionicBackdrop.release();
            }, 1000);
        };
        $scope.items = [1, 2, 3];
        $scope.doRefresh = function() {
            $http.get('/data/new-items.json').success(function(newItems) {
                $scope.items = newItems;
            }).finally(function() {
                // Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            });
        };
        $scope.shouldShowDelete = true;
        $scope.shouldShowReorder = true;
        $scope.listCanSwipe = true;
        $scope.products = [{
            title: "test title 1",
            img: "/img/ionic.png",
            description: "test desctest desctest desctest desctest desc",
        }, {
            title: "test title 2",
            img: "/img/ionic.png",
            description: "test desctest desctest desctest desctest desc",
        }, {
            title: "test title 3",
            img: "/img/ionic.png",
            description: "test desctest desctest desctest desctest desc",
        }, {
            title: "test title 4",
            img: "/img/ionic.png",
            description: "test desctest desctest desctest desctest desc",
        }, ];
        $scope.showLoading = function() {
            $ionicLoading.show({
                template: 'Loading...'
            });
            $timeout(function() {
                $scope.hideLoading();
            }, 3000);
        };
        $scope.hideLoading = function() {
            $ionicLoading.hide();
        };
        //---modal portion--
        $ionicModal.fromTemplateUrl('my-modal.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.modal = modal;
        });
        $scope.openModal = function() {
            $scope.modal.show();
        };
        $scope.closeModal = function() {
            $scope.modal.hide();
        };
        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function() {
            $scope.modal.remove();
        });
        // Execute action on hide modal
        $scope.$on('modal.hidden', function() {
            // Execute action
        });
        // Execute action on remove modal
        $scope.$on('modal.removed', function() {
            // Execute action
        });
    })

    .controller('DashCtrl', function($scope, $ionicSideMenuDelegate, $ionicTabsDelegate) {

        var deploy = new Ionic.Deploy();
        // Update app code with new release from Ionic Deploy
        $scope.doUpdate = function() {
            deploy.update().then(function(res) {
                console.log('Ionic Deploy: Update Success! ', res);
            }, function(err) {
                console.log('Ionic Deploy: Update error! ', err);
            }, function(prog) {
                console.log('Ionic Deploy: Progress... ', prog);
            });
        };
        // Check Ionic Deploy for new code
        $scope.checkForUpdates = function() {
            console.log('Ionic Deploy: Checking for updates');
            deploy.check().then(function(hasUpdate) {
                console.log('Ionic Deploy: Update available: ' + hasUpdate);
                $scope.hasUpdate = hasUpdate;
            }, function(err) {
                console.error('Ionic Deploy: Unable to check for updates', err);
            });
        }
$ionicSideMenuDelegate.canDragContent(false);
            $scope.previousTab = 0;
$scope.currentTab = 0;
$scope.$watch(function() {return $ionicTabsDelegate.selectedIndex();}, function(index) {
      $scope.previousTab = $scope.currentTab;
      $scope.currentTab = index;
});
    })
// ---------

.controller('gridCtrl', function($scope,$rootScope, $timeout, imageService, ionicMaterialMotion, ionicMaterialInk, $ionicFilterBar) { 
    var rowGridContainer = document.getElementById('row-grid');
    var rowGridInit = false;
    $scope.noMoreItemsAvailable = false;
    $scope.loadMore1 = function(){
        console.log("cal loadmore");
        loadMore()
    };

    $scope.$on('$stateChangeSuccess', function() {


    });
    $scope.$on('$ionicView.loaded', function() {



    });
    $scope.$on('$ionicView.afterEnter', function() {
        $timeout(function () {
            document.getElementById('upload-image').classList.toggle('on');
            rowGrid(rowGridContainer, {itemSelector: ".row-grid-item", minMargin: 10, maxMargin: 25, firstItemClass: "first-item", lastRowClass: 'last-row', resize: true});
            rowGridInit = true;
        }, 200);
    });
    
    var changeSearchCriteriaOrientation = true;

    $rootScope.toggleSearchCriteriaOrientation = function() {
        if (changeSearchCriteriaOrientation == false) {
            $rootScope.searchCriteria.orientation = 'horizontal';
            changeSearchCriteriaOrientation = true;
        } else{
            $rootScope.searchCriteria.orientation = 'vertical';
            changeSearchCriteriaOrientation = false;
        }
        $scope.doRefresh();
    };


    $scope.$on('$ionicView.beforeEnter', function() {
        // loadMore();
        $rootScope.showSearchCriteriaOrientation = true;
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    init();
    function init() {
        // Set Ink
        ionicMaterialInk.displayEffect();
    }

    function loadMore() {
        imageService
            .getImages($rootScope.searchCriteria)
            .then(function (result) {
                $rootScope.images = $rootScope.images.concat(result);
                // $rootScope.$apply();
            }, function (error) {   
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(){
                    calculateOnImageLoad(function(){
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        $rootScope.searchCriteria.page++;
                        // ionicMaterialMotion.fadeSlideInRight();
                        if (rowGridInit) {
                            rowGrid(rowGridContainer, 'appended');
                        } else {
                            rowGrid(rowGridContainer, {itemSelector: ".row-grid-item", minMargin: 10, maxMargin: 25, firstItemClass: "first-item", lastRowClass: 'last-row', resize: true});
                            rowGridInit = true;
                        }
                    });

                },200);
            });
    }

    $scope.doRefresh = function() {
        rowGridInit = false;
        $rootScope.searchCriteria.page = 1;
        $rootScope.images = [];
        $timeout(function(){loadMore()},0);
    }

    $rootScope.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: $rootScope.images,
        update: function (filteredItems) {
            if (filteredItems) {
                $rootScope.searchCriteria.page = 1;
                $rootScope.images = filteredItems;
                $timeout(function(){
                    calculateOnImageLoad(null);
                    rowGrid(rowGridContainer, {itemSelector: ".row-grid-item", minMargin: 10, maxMargin: 25, firstItemClass: "first-item", lastRowClass: 'last-row', resize: true});
                },0);
            }
        },
        cancel : function (items) {
            // $rootScope.searchCriteria.page = 1;
            // loadMore();
            // setTimeout(function(){
            //  calculateOnImageLoad(null);
            // },0);
        },
        filterProperties: 'tags'
      });
    }

    function calculateOnImageLoad(cb) {

        // for tesing with out event performance
        if (typeof cb == 'function') {
            cb();
            return;
        }


        var currentlyLoaded = 0;

        var items = document.querySelectorAll(".masonry img"), 
            totalImg = items.length, 
            img;
        // console.log(items);
        for (var i = 0; i < totalImg; i++) {
            img = items[i];
            
            (function(i) {
                if (img.complete) {
                    currentlyLoaded++;
                    items[i].style.opacity = 1;
                    items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                    return;
                }
                img.addEventListener("load", function(loadimg) {
                    currentlyLoaded++;
                    items[i].style.opacity = 1;
                    items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }

                });
                img.addEventListener("error", function(errorimg) {
                    currentlyLoaded++;
                    items[i].style.opacity = 1;
                    items[i].parentNode.classList.remove('loading');
                    items[i].parentNode.classList.add('error');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                });
            })(i);
        }
    }
})


.controller('macyCtrl', function($scope,$rootScope, $timeout, imageService, ionicMaterialMotion, ionicMaterialInk, $ionicFilterBar) { 
    $scope.hasMoreImages = true;
    $scope.loadMore1 = function(){
        console.log("cal loadmore");
        loadMore()
    };

    $scope.$on('$stateChangeSuccess', function() {
    });
    $scope.$on('$ionicView.loaded', function() {
    });
    $scope.$on('$ionicView.afterEnter', function() {
    });
    
    var changeSearchCriteriaOrientation = true;

    $rootScope.toggleSearchCriteriaOrientation = function() {
        if (changeSearchCriteriaOrientation == false) {
            $rootScope.searchCriteria.orientation = 'horizontal';
            changeSearchCriteriaOrientation = true;
        } else{
            $rootScope.searchCriteria.orientation = 'vertical';
            changeSearchCriteriaOrientation = false;
        }
        $scope.doRefresh();
    };


    $scope.$on('$ionicView.beforeEnter', function() {
        // loadMore();
        $rootScope.showSearchCriteriaOrientation = true;
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    init();
    function init() {
        // Set Ink
        ionicMaterialInk.displayEffect();
    }
    var isLoadMoreStart = false;
    function loadMore() {
        // $scope.hasMoreImages = false;
        if (isLoadMoreStart) {
            return;
        }
        isLoadMoreStart = true;
        imageService
            .getImages($rootScope.searchCriteria)
            .then(function (result) {
                $rootScope.images = $rootScope.images.concat(result);
                // $scope.hasMoreImages = true;
                // $rootScope.$apply();
            }, function (error) {
                $scope.hasMoreImages = false;
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(items) {
                    macyLoader();
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    isLoadMoreStart = false;
                    // -------------------------------------------------
                },00);
            });
    }

    function macyLoader(){
        Macy.init({
            container: '#macy-container',
            trueOrder: false,
            waitForImages: false, 
            margin: 5,
            columns: 2,
            breakAt: {
                500: 3,
                400: 2,
                250: 1

            }
        });
        
        Macy.onImageLoad(function(img) {
                img.style.opacity = 1;
                img.parentNode.parentNode.classList.remove('loading');
                // Macy.recalculate();
            }, function () {
                console.log("----------complete load all image--------------")
                // Macy.recalculate();
            }, function(img) {
                img.style.opacity = 1;
                img.parentNode.parentNode.classList.remove('error');
                // Macy.recalculate();
        });
        // Macy.recalculate();

    }
    $scope.doRefresh = function() {
        rowGridInit = false;
        $rootScope.searchCriteria.page = 1;
        $rootScope.images = [];
        $timeout(function(){loadMore()},0);
    }

    $rootScope.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: $rootScope.images,
        update: function (filteredItems) {
            if (filteredItems) {
                $rootScope.searchCriteria.page = 1;
                $rootScope.images = filteredItems;
                $timeout(function(){
                    macyLoader();
                },0);
            }
        },
        cancel : function (items) {
        },
        filterProperties: 'tags'
      });
    }
})



.controller('brickCtrl', function($log,$scope,$rootScope, $timeout, imageService, ionicMaterialMotion, ionicMaterialInk, $ionicFilterBar) { 

    var vm = this,
        instance, 
        rowGridInit = false, 
        self = this,
        changeSearchCriteriaOrientation = true,
        isLoadMoreStart = false,
        sizes = [
            { columns: 3, gutter: 5 },
            { mq: '400px', columns: 3, gutter: 5 },
            { mq: '500px', columns: 4, gutter: 5 }
        ];

    $scope.hasMoreImages = true;

    this.loadMore = loadMore;
    this.doRefresh = doRefresh;

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.beforeEnter', function() {});
    $scope.$on('$ionicView.afterEnter', function() {
        $rootScope.showSearchCriteriaOrientation = true;
    });
    $scope.$on('$ionicView.afterLeave', function() {
        $rootScope.showSearchCriteriaOrientation = false;
    });

    $rootScope.toggleSearchCriteriaOrientation = function() {
        if (changeSearchCriteriaOrientation == false) {
            $rootScope.searchCriteria.orientation = 'horizontal';
            changeSearchCriteriaOrientation = true;
        } else{
            $rootScope.searchCriteria.orientation = 'vertical';
            changeSearchCriteriaOrientation = false;
        }
        $scope.doRefresh();
    };
    $rootScope.showFilterBar = function () {
      filterBarInstance = $ionicFilterBar.show({
        items: $rootScope.images,
        debounce:true,
        // favoritesEnabled:true,
        update: function (filteredItems) {
            if (filteredItems) {
                if (filteredItems.length < $rootScope.images.length) {
                    $rootScope.searchCriteria.page = 1;
                    $rootScope.images = filteredItems;
                    rowGridInit = false;
                    if (filteredItems.length > 0 ) {
                        $timeout(function(){
                            brickLoader();
                        },0);
                    }
                }
            }
        },
        cancel : function (items) {
        },
        done: function(){

        },
        filterProperties: 'tags'
      });
    }
    // ------carousel-----
    this.carouselOptions = {
            carouselId    : 'carousel',
            align         : 'left',
            selectFirst   : true,
            centerOnSelect: false,
            // template      : null
            template      : 'templates/carousel-template.html',
            maxScroll:0
        };
    this.carouselData = createArray(8);
    this.onSelectCarousel = function (item) {
        //vm.itemActive = item;
        console.log('Carousel item selected:', item);
    };
    function createArray(total, randomImg) {
        randomImg                = typeof randomImg === 'undefined' ? false : randomImg;
        var i, model, imgId, arr = [];
        for (i = 0; i < total; i++) {
            model = {
                id     : i,
                display: 'item ' + i
            };
            if (i === 2 || i === 13) {
                model.display = 'longer ' + model.display;
            }
            if (randomImg) {
                imgId     = Math.floor(Math.random() * 10000);
                model.src = 'http://lorempixel.com/120/80/?' + imgId
            }
            arr.push(model);
        }

        return arr;
    }
    // -----------
    init();

    function init() {
        // Set Ink
        ionicMaterialInk.displayEffect();
    }
    function loadMore() {
        if (isLoadMoreStart) {
            return;
        }
        isLoadMoreStart = true;
        imageService
            .getImages($rootScope.searchCriteria)
            .then(function (result) {
                $rootScope.searchCriteria.page += 1;
                $rootScope.images = $rootScope.images.concat(result);
            }, function (error) {
                $scope.hasMoreImages = false;
                console.log(error);
            })
            .finally(function(result){
                $timeout(function(items) {
                    calculateOnImageLoad(function(){
                        brickLoader();
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                        isLoadMoreStart = false;
                    });
                },200);
            });
    }
    function brickLoader(){
        if (!rowGridInit) {
            instance = Bricks({
               container: '#brick-container',
               sizes: sizes,
               packed: 'data-packed'
            })
            instance .resize(true);
            instance.pack();
            instance
            .on('pack',   () => console.log('ALL grid items packed.'))
            .on('update', () => console.log('NEW grid items packed.'))
            .on('resize', function (size) {$log.info(size);})
            rowGridInit = true;
            $log.info("#####--------init--------######");
        } else {
            try{
                instance.update()
            } catch (e){}
            $log.info("#####--------update--------######");
        }
    }
    function doRefresh() {
        rowGridInit = false;
        $rootScope.searchCriteria.page = 1;
        $rootScope.images = [];
        $timeout(function(){loadMore()},0);
    }
    function calculateOnImageLoad(cb) {
        var currentlyLoaded = 0;

        var items = document.querySelectorAll("#brick-container > *:not([data-packed]) img"), 
            totalImg = items.length, 
            img;
        for (var i = 0; i < totalImg; i++) {
            img = items[i];
            
            (function(i) {
                if (img.complete) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                    return;
                }
                img.addEventListener("load", function(loadimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                        setOpacity1();
                    }
                });
                img.addEventListener("error", function(errorimg) {
                    currentlyLoaded++;
                    // items[i].style.opacity = 1;
                    // items[i].parentNode.classList.remove('loading');
                    items[i].parentNode.classList.add('error');
                    if (currentlyLoaded == totalImg) {
                        if (typeof cb == 'function') {
                            cb();
                        }
                    }
                });
            })(i);
        }
        function setOpacity1(){
            for (var i = 0; i < totalImg; i++) {
                items[i].style.opacity = 1;
                items[i].parentNode.classList.remove('loading');
            }
        }
    }
})

.controller('imageCtrl', function($scope,$rootScope,$state,$stateParams, $ionicSlideBoxDelegate, $ionicGesture) {
    if (!$rootScope.images[parseInt($stateParams.id)]) {
        $state.go('app.grid');
    }
    $scope.image_slides = [];
    for (var i = 0; i < 5; i++) {
        if (!$rootScope.images[parseInt($stateParams.id)]) {
            $state.go('app.grid');
        }
        $scope.image_slides.push({
            'src': $rootScope.images[parseInt($stateParams.id) + i].webformatURL,
        });
    }
    document.getElementsByTagName("ion-header-bar")

    $scope.slideHasChanged = function() {
        $scope.image_slides.splice($scope.image_slides.length - 1)
        $scope.image_slides.push({
            // 'src': 'http://lorempixel.com/360/640?' + ($ionicSlideBoxDelegate.currentIndex() + 3)
            'src': $rootScope.images[parseInt($stateParams.id) + (i++)].webformatURL
        });
        $ionicSlideBoxDelegate.update();
    };
    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.$parent.navBarTransparent = true;
        $scope.$parent.displaySearchButton = false;
        $scope.$parent.hideSheetFav = true;
        document.querySelector('ion-nav-view[name="fabContent"]').style.display = 'none';

    });
    $scope.$on('$ionicView.afterLeave', function() {
        $scope.$parent.navBarTransparent = false;
        $scope.$parent.displaySearchButton = true;
        document.querySelector('ion-nav-view[name="fabContent"]').style.display = 'block';

    });
    $scope.$on('$ionicView.afterEnter', function() {
        setTimeout(function() {
            document.querySelector('.slider-container .slider-slides').style.transform = "translate(0px, 0px) translateZ(0px)";
        }, 500);
        document.querySelector('.slider-container .slider-slides').style.transform = "translate(-60px, 0px) translateZ(0px)";
    });
})


.directive('tabsSwipable', ['$ionicGesture', function($ionicGesture){
    //
    // make ionTabs swipable. leftswipe -> nextTab, rightswipe -> prevTab
    // Usage: just add this as an attribute in the ionTabs tag
    // <ion-tabs tabs-swipable> ... </ion-tabs>
    //
    return {
        restrict: 'A',
        require: 'ionTabs',
        link: function(scope, elm, attrs, tabsCtrl){
            var onSwipeLeft = function(){
                var target = tabsCtrl.selectedIndex() + 1;
                if(target < tabsCtrl.tabs.length){
                    scope.$apply(tabsCtrl.select(target));
                }
            };
            var onSwipeRight = function(){
                var target = tabsCtrl.selectedIndex() - 1;
                if(target >= 0){
                    scope.$apply(tabsCtrl.select(target));
                }
            };
            
            var swipeGesture = $ionicGesture.on('swipeleft', onSwipeLeft, elm).on('swiperight', onSwipeRight);
            scope.$on('$destroy', function() {
                $ionicGesture.off(swipeGesture, 'swipeleft', onSwipeLeft);
                $ionicGesture.off(swipeGesture, 'swiperight', onSwipeRight);
            });
        }
    };
}])



.directive('scrollWatch', function($rootScope) {
  return function(scope, elem, attr) {
    var start = 150;
    document.getElementById(attr.subHeader).style.top = '44px';
    elem[0].style.top = '88px';
    elem[0].style.transition = 'top 0.25s ease';
    elem.bind('scroll', function(e) {
        var scrollTop = (e.detail)?e.detail.scrollTop : e.currentTarget.scrollTop;
      if(e.currentTarget.scrollTop > start) {
        document.getElementById(attr.subHeader).style.top = '0px';
        elem[0].style.top = '44px';
      } else {
        document.getElementById(attr.subHeader).style.top = '44px';
        elem[0].style.top = '88px';
      }
      start = scrollTop;
    });
  };
})

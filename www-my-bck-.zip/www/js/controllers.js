angular.module('starter.controllers', [])
// angular.module('starter.controllers', ['wu.masonry','infinite-scroll'])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //$scope.$on('$ionicView.enter', function(e) {
    //});
    // Form data for the login modal
    $scope.loginData = {};
    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/login.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    // Open the login modal
    $scope.login = function() {
        $scope.modal.show();
    };
    // Perform the login action when the user submits the login form
    $scope.doLogin = function() {
        console.log('Doing login', $scope.loginData);
        // Simulate a login delay. Remove this and replace with your login
        // code if using a login system
        $timeout(function() {
            $scope.closeLogin();
        }, 1000);
    };
})

.controller('PlaylistsCtrl', function($scope) {
    $scope.playlists = [{
        title: 'Reggae',
        id: 1
    }, {
        title: 'Chill',
        id: 2
    }, {
        title: 'Dubstep',
        id: 3
    }, {
        title: 'Indie',
        id: 4
    }, {
        title: 'Rap',
        id: 5
    }, {
        title: 'Cowbell',
        id: 6
    }];
        $scope.$on('$ionicView.loaded', function() { //This just one when leaving, which happens when I logout
        console.log("App view (menu) loaded.");
        console.log(arguments);
        /* Start rowGrid.js */
        // setTimeout(function(){
        // var container = document.getElementsByClassName('container')[0];
        // // rowGrid(container, {itemSelector: '.item', minMargin: 10, maxMargin: 25, firstItemClass: 'first-item', lastRowClass: 'last-row', resize: true, minWidth: 500});
        // rowGrid(container, {itemSelector: '.grid-item', minMargin: 10, maxMargin: 25, firstItemClass: 'first-item', lastRowClass: 'last-row', resize: true});
        // },3000);
    });
    $scope.$on('$ionicView.beforeEnter', function() { //This just one when leaving, which happens when I logout
        console.log("App view (menu) beforeEnter.");
        console.log(arguments);
    });
    $scope.$on('$ionicView.beforeLeave', function() { //This just one when leaving, which happens when I logout
        console.log("App view (menu) beforeLeave.");
        console.log(arguments);
    });
    $scope.$on('$ionicView.afterEnter', function() { //This just one when leaving, which happens when I logout
        console.log("App view (menu) afterEnter.");
        console.log(arguments);
    });
    $scope.$on('$ionicView.afterLeave', function() { //This just one when leaving, which happens when I logout
        console.log("App view (menu) afterLeave.");
        console.log(arguments);
    });
    $scope.$on('$ionicView.unloaded', function() { //This just one when leaving, which happens when I logout
        console.log("App view (menu) unloaded.");
        console.log(arguments);
    });
    document.addEventListener('DOMContentLoaded', function() {});
})

.controller('BrowseCtrl', function($scope) {
    $scope.images = [];
    $scope.totalImg = 0;
    function loadImg(limit) {
        var rand_size = [{
                'w': 480,
                'h': 885
            }, {
                'w': 360,
                'h': 640
            }, {
                'w': 960,
                'h': 640
            }, {
                'w': 425,
                'h': 590
            }],
            w, h;
        for (var i = $scope.totalImg; i < $scope.totalImg + limit; i++) {
            w = rand_size[parseInt(Math.random() * 100 % 4)].w;
            h = rand_size[parseInt(Math.random() * 100 % 4)].h;
            $scope.images.push({
                'src': 'http://unsplash.it/' + w + '/' + h + '?image=' + i
            });
        }
    	$scope.totalImg += limit;
    	$scope.$broadcast('scroll.infiniteScrollComplete');
    }
    $scope.loadMore = function() {
    	console.log("twicw priblem");
        setTimeout(function(items) {
            loadImg(12);
            
        new AnimOnScroll(document.getElementById('grid'), {
            minDuration: 0.4,
            maxDuration: 0.7,
            viewportFactor: 0.2
        });
        },000);
    };
    $scope.$on('$ionicView.afterEnter', function() { //This is fired twice in a row
        // $scope.loadMore();
    });
    $scope.$on('$stateChangeSuccess', function() {
    });
    // loadImg(12);
})

.controller('macyCtrl', function($scope) {
    $scope.images = [];
    $scope.totalImg = 0;
    $scope.noMoreItemsAvailable = false;
    $scope.loadMore1 = function(){
    	console.log("cal loadmore");
    	loadMore()
    };

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.afterEnter', function() {});

    init();
    function init() {
    	// loadMore();
    }
    function loadMore() {
    	console.log("twicw priblem");
        loadImg(12);
        var items = document.querySelectorAll("#macy-container .demo");
        for (var i = 0; i < items.length; i++) {
        	// items[i].classList.add('loading');
        }
        
        setTimeout(function(items) {
		        Macy.init({
		            container: '#macy-container',
		            trueOrder: false,
		            waitForImages: false, 
		            margin: 5,
		            columns: 2,
		            breakAt: {
		                250: 1
		            }
		        });
		        
		        Macy.onImageLoad(function(img) {
			            img.style.opacity = 1;
			            img.parentNode.parentNode.classList.remove('loading');
			            // Macy.recalculate();
			        }, function () {
			        	console.log("----------complete load all image--------------")
		            	// Macy.recalculate();
			        }, function(img) {
			            img.style.opacity = 1;
			            img.parentNode.parentNode.classList.remove('error');
			            // img.src = 'img/ic_broken_image_black_48px.svg';
			            // Macy.recalculate();
		        });
		        // Macy.recalculate();
		    	$scope.$broadcast('scroll.infiniteScrollComplete');
	    	// -------------------------------------------------
        },00);
    }
    function loadImg(limit) {
        var rand_size = [{
                'w': 480,
                'h': 885
            }, {
                'w': 360,
                'h': 640
            }, {
                'w': 960,
                'h': 640
            }, {
                'w': 425,
                'h': 590
            }],
            w, h;
        for (var i = $scope.totalImg; i < $scope.totalImg + limit; i++) {
            w = rand_size[parseInt(Math.random() * 100 % 4)].w;
            h = rand_size[parseInt(Math.random() * 100 % 4)].h;
            $scope.images.push({
                'src': 'http://unsplash.it/' + w + '/' + h + '?image=' + i
            });
        }
    	$scope.totalImg += 12;
    	// Macy.recalculate();
    }
})

.controller('gridCtrl', function($scope) {
    $scope.images = [];
    $scope.totalImg = 0;
    $scope.noMoreItemsAvailable = false;
    $scope.loadMore1 = function(){
    	console.log("cal loadmore");
    	loadMore()
    };

    $scope.$on('$stateChangeSuccess', function() {});
    $scope.$on('$ionicView.loaded', function() {});
    $scope.$on('$ionicView.afterEnter', function() {});

    init();
    function init() {
    	// loadMore();
    }
    function loadMore() {
    	console.log("twicw priblem");
        
        setTimeout(function(items) {
        	loadImg(12);
		    $scope.$broadcast('scroll.infiniteScrollComplete');
        },2000);
    }
    function loadImg(limit) {
        var rand_size = [{
                'w': 480,
                'h': 885
            }, {
                'w': 360,
                'h': 640
            }, {
                'w': 960,
                'h': 640
            }, {
                'w': 425,
                'h': 590
            }],
            w, h;
        for (var i = $scope.totalImg; i < $scope.totalImg + limit; i++) {
            w = rand_size[parseInt(Math.random() * 100 % 4)].w;
            h = rand_size[parseInt(Math.random() * 100 % 4)].h;
            $scope.images.push({
                'src': 'http://unsplash.it/' + w + '/' + h + '?image=' + i
            });
        }
    	$scope.totalImg += 12;
    	// Macy.recalculate();
    }
    $scope.doRefresh = function() {
    	$scope.images = [];
        $http.get('/data/new-items.json').success(function(newItems) {
            $scope.items = newItems;
        }).finally(function() {
            // Stop the ion-refresher from spinning
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
})

.controller('imageCtrl', function($scope, ImageSearch, $ionicSlideBoxDelegate, $ionicGesture) {
    $scope.image_slides = [{
        'src': 'http://lorempixel.com/360/640?1'
    }, {
        'src': 'http://lorempixel.com/960/640?2'
    }, {
        'src': 'http://lorempixel.com/360/640?3'
    }];
    $scope.slideHasChanged = function() {
        $scope.image_slides.push({
            'src': 'http://lorempixel.com/360/640?' + ($ionicSlideBoxDelegate.currentIndex() + 3)
        });
        $ionicSlideBoxDelegate.update();
    };
    $scope.$on('$ionicView.afterEnter', function() {
        setTimeout(function() {
            document.querySelector('.slider-container .slider-slides').style.transform = "translate(0px, 0px) translateZ(0px)";
        }, 500);
        document.querySelector('.slider-container .slider-slides').style.transform = "translate(-60px, 0px) translateZ(0px)";
    });
})

.controller('DemoCtrl', function ($scope,Reddit) {
		$scope.bricks  = new Reddit();
		function genBrick() {
		    return {
		        src: 'http://lorempixel.com/g/400/200/?' + ~~(Math.random() * 10000)
		    };
		};


		$scope.remove = function remove() {
		    $scope.bricks.splice(
		        ~~(Math.random() * $scope.bricks.length),
		        1
		    )
		};
		console.log($scope.bricks);
})
.factory('Reddit', function($http) {
		var Reddit = function() {
		this.items = [

		{'src':'http://lorempixel.com/350/200/sports/1', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/350/200/sports/2', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/350/200/sports/3/', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/320/200/sports/7/', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/460/350/food/2/', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/320/400/food/2/', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/320/200/food/4/', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/450/400/food/2/', 'title':'Lorem Ipsum and shit'},
		{'src':'http://lorempixel.com/500/350/sports/5/', 'title':'Lorem Ipsum and shit'},

		];
		this.busy = false;

		this.after = '';
		};

		Reddit.prototype.nextPage = function() {
		if (this.busy) return;
		function getRandomInt(min, max) {
		  return Math.floor(Math.random() * (max - min + 1) + min);
		}
		this.busy = true;

		var url = "http://api.reddit.com/hot?after=" + this.after + "&jsonp=JSON_CALLBACK";
		$http.jsonp(url).success(function(data) {
		  
		  // console.log("page " + ii);
		     
		   //var width=300;
		   var items = data.data.children;
		   
		   for (var i = 0; i < items.length - 20; i++) {

		     this.items.push({'src':'http://lorempixel.com/320/'+ getRandomInt(20,50) +'0/?5142','title':'"' + items[i].data.title +'"'});
		   };


		  this.busy = false;


		  

		}.bind(this));
		};

		return Reddit;
})

.controller('PlaylistCtrl', function($scope, $ionicActionSheet, $ionicModal, $ionicBackdrop, $ionicLoading, $timeout, $http, $stateParams) {
    $scope.showActionSheet = function() {
        // Show the action sheet
        var hideSheet = $ionicActionSheet.show({
            buttons: [{
                text: '<b>Share</b> This'
            }, {
                text: 'Move'
            }],
            destructiveText: 'Delete',
            titleText: 'Modify your album',
            cancelText: 'Cancel',
            cancel: function() {
                // add cancel code..
            },
            buttonClicked: function(index) {
                return true;
            }
        });
        // For example's sake, hide the sheet after two seconds
        //  $timeout(function() {
        // hideSheet();
        //  }, 20000);
    };
    $scope.showBackDrop = function() {
        $ionicBackdrop.retain();
        $timeout(function() {
            $ionicBackdrop.release();
        }, 1000);
    };
    $scope.items = [1, 2, 3];
    $scope.doRefresh = function() {
        $http.get('/data/new-items.json').success(function(newItems) {
            $scope.items = newItems;
        }).finally(function() {
            // Stop the ion-refresher from spinning
            $scope.$broadcast('scroll.refreshComplete');
        });
    };
    $scope.shouldShowDelete = true;
    $scope.shouldShowReorder = true;
    $scope.listCanSwipe = true;
    $scope.products = [{
        title: "test title 1",
        img: "/img/ionic.png",
        description: "test desctest desctest desctest desctest desc",
    }, {
        title: "test title 2",
        img: "/img/ionic.png",
        description: "test desctest desctest desctest desctest desc",
    }, {
        title: "test title 3",
        img: "/img/ionic.png",
        description: "test desctest desctest desctest desctest desc",
    }, {
        title: "test title 4",
        img: "/img/ionic.png",
        description: "test desctest desctest desctest desctest desc",
    }, ];
    $scope.showLoading = function() {
        $ionicLoading.show({
            template: 'Loading...'
        });
        $timeout(function() {
            $scope.hideLoading();
        }, 3000);
    };
    $scope.hideLoading = function() {
        $ionicLoading.hide();
    };
    //---modal portion--
    $ionicModal.fromTemplateUrl('my-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function() {
        $scope.modal.show();
    };
    $scope.closeModal = function() {
        $scope.modal.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hidden', function() {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function() {
        // Execute action
    });
})

.controller('DashCtrl', function($scope) {
    var deploy = new Ionic.Deploy();
    // Update app code with new release from Ionic Deploy
    $scope.doUpdate = function() {
        deploy.update().then(function(res) {
            console.log('Ionic Deploy: Update Success! ', res);
        }, function(err) {
            console.log('Ionic Deploy: Update error! ', err);
        }, function(prog) {
            console.log('Ionic Deploy: Progress... ', prog);
        });
    };
    // Check Ionic Deploy for new code
    $scope.checkForUpdates = function() {
        console.log('Ionic Deploy: Checking for updates');
        deploy.check().then(function(hasUpdate) {
            console.log('Ionic Deploy: Update available: ' + hasUpdate);
            $scope.hasUpdate = hasUpdate;
        }, function(err) {
            console.error('Ionic Deploy: Unable to check for updates', err);
        });
    }
});